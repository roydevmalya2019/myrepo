var http = require('http');
var dt = require('./myfirstmodule');
var url = require('url');
var fs = require('fs');

// http.createServer(function(req, res){
	// res.writeHead(200,{'Content-Type':'text/html'});
	// res.write('hello world</br>');
	// res.write("\nThe date and time are currently: " + dt.myDateTime());
	// res.write("</br>"+req.url);
	// res.write("</br>");
	// var q = url.parse(req.url, true).query;
	// var txt = q.year+" "+ q.month;
	// res.end(txt);
// }).listen(8080);

// File System Module
// read files

// http.createServer(function(req,res){
	
	// fs.readFile('demofile1.html', function(err,data){
	// res.writeHead(200,{"Content-Type":"text/html"});
	// res.write(data);
	// res.end();
	// });
	
// }).listen(8080);


// create files

// fs.writeFile();
// fs.open();
// fs.appendFile();

// fs.appendFile('mynewfile1.txt','Hello Content!', function(err){
	// if(err) throw err;
	// console.log('Saved!');
// });
// fs.open('mynewfile2.txt','w', function(err,file){
	// if(err) throw err;
	// console.log('Saved');
// });
// fs.writeFile('mynewfile3.txt', 'Hello Content!', function(err){
	// if(err) throw err;
	// console.log('Saved');
// })


// update file


// fs.appendFile();
// fs.writeFile();


// fs.appendFile('mynewfile1.txt','This is my text', function(err){
	// if(err) throw err;
	// console.log('Updated');
// });
// fs.writeFile('mynewfile3.txt','This is my text', function(err){
	// if(err) throw err;
	// console.log('Replaced');
// });



// Delete files
//fs.unlink();


// fs.unlink('mynewfile2.txt', function(err){
	// if(err) throw err;
	// console.log('File Deleted!');
// })


//file rename

// fs.rename('mynewfile1.txt','myrenamedfile.txt', function(err){
	// if(err) throw err;
	// console.log('File Renamed!');
// });


//------Node js URL Module------//


// var adr = 'http://localhost:8080/default.htm?year=2019&month=february';
// var q = url.parse(adr, true);

// console.log(q.host);
// console.log(q.pathname);
// console.log(q.search);

// var qdata = q.query;
// console.log(qdata.month);


// http.createServer(function(req,res){
	// var q = url.parse(req.url, true);
	// var filename = "."+q.pathname;
	// fs.readFile(filename, function(err,data){
		// if(err){
			// res.writeHead(404,{"Content-Type":"text/html"});
			// return res.end("404 Not Found");
		// }
		// res.writeHead(200, {"Content-Type":"text/html"});
		// res.write(data);
		// return res.end();
	// });
// }).listen(8080);

//------Node Js Events-------//
var events = require('events');
var eventEmitter = new events.EventEmitter();

// // create an event handler
// var myEventHandler = function(){
	// console.log('I hear a scream');
// };

//assign the event handler to an event
//eventEmitter.on('scream', myEventHandler);

//fire the scream event
//eventEmitter.emit('scream');

// listener #1
// var listner1 = function listner1() {
   // console.log('listner1 executed.');
// }

// listener #2
// var listner2 = function listner2() {
  // console.log('listner2 executed.');
// }

// Bind the connection event with the listner1 function
//eventEmitter.addListener('connection', listner1);

// Bind the connection event with the listner2 function
//eventEmitter.on('connection', listner2);

// var eventListeners = require('events').EventEmitter.listenerCount(eventEmitter,'connection');
// console.log(eventListeners + " Listner(s) listening to connection event");

// Fire the connection event 
//eventEmitter.emit('connection');

// Remove the binding of listner1 function
// eventEmitter.removeListener('connection', listner1);
// console.log("Listner1 will not listen now.");

// Fire the connection event 
//eventEmitter.emit('connection');

//eventListeners = require('events').EventEmitter.listenerCount(eventEmitter,'connection');
//console.log(eventListeners + " Listner(s) listening to connection event");

// Remove the binding of listner2 function
//eventEmitter.removeListener('connection', listner2);
//console.log("Listner2 will not listen now.");

// Fire the connection event 
//eventEmitter.emit('connection');
// eventListeners = require('events').EventEmitter.listenerCount(eventEmitter,'connection');
// console.log(eventListeners + " Listner(s) listening to connection event");



// console.log("Program Ended.");




//Node Js Upload Files
//----------The Formidable Module-----------//
// step1. create an upload form
// parse the uploaded file
// save the file
// var formidable = require('formidable');
// http.createServer(function (req, res) {
  // if (req.url == '/fileupload') {
    // var form = new formidable.IncomingForm();
    // form.parse(req, function (err, fields, files) {
      // var oldpath = files.filetoupload.path;
      // var newpath = 'C:/Users/761218/Desktop/Devmalya/' + files.filetoupload.name;
      // fs.rename(oldpath, newpath, function (err) {
        // if (err) throw err;
        // res.write('File uploaded and moved!');
        // res.end();
      // });
 // });
  // } else {
    // res.writeHead(200, {'Content-Type': 'text/html'});
    // res.write('<form action="fileupload" method="post" enctype="multipart/form-data">');
    // res.write('<input type="file" name="filetoupload"><br>');
    // res.write('<input type="submit">');
    // res.write('</form>');
    // return res.end();
  // }
// }).listen(8080);



//---------Node Js Buffers-----------
//creating buffers
//method 1
// var buf = new Buffer(256);

// //method 2
// var buf2 = new Buffer([10,20,30,40,50],[60,70,80,90,100]);
// console.log("buf2 is:" + buf2.toString(undefined,0,5));

// //method 3
// var buf3 = new Buffer("Simply Easy Learning","utf-8");


// //writing to buffers
// //buf.write(string[, offset][, length][, encoding])
// len = buf.write("Simply Easy Learning");
// console.log("Octets Written: "+ len);


// //Reading from Buffers
// //buf.toString([encoding][, start][, end])

// buf = new Buffer(26);
// for(var i = 0;i<26;i++){
	// buf[i] = i+97;
// }
// console.log(buf.toString('ascii'));
// console.log(buf.toString('ascii',0,5));
// console.log(buf.toString('utf-8',0,5));
// console.log(buf.toString(undefined,0,5)); //encoding defaults to utf-8

// buf = new Buffer('Simply Easy Learning');
// var json = buf.toJSON(buf);

// console.log(json);


// //concatenate buffers
// buf = new Buffer("TutorialsPoint");
// buf2 = new Buffer("Simply Easy Learning");
// buf3 = Buffer.concat([buf, buf2]);

// console.log("buffer 3 content: "+buf3.toString());

//------Node Js Streams---------
// var data = '';

// var readerStream = fs.createReadStream('myrenamedfile.txt');
// readerStream.setEncoding('UTF8');

// readerStream.on('data', function(chunk){
	
	// data += chunk;
	
// });

// readerStream.on('end',function(){
	// console.log(data);
// });


// readerStream.on('error', function(err){
	// console.log(err.stack);
// })

// console.log('Program Ended');


// var data = "Simply Easy Learning";

// //create writable stream

// var writerStream = fs.createWriteStream('output.txt');

// //write the data to stream with encoding to be utf8
// writerStream.write(data,'UTF8');

// //mark the end of the file
// writerStream.end();

// writerStream.on('finish',function(){
	// console.log('Write Completed');
// });
// writerStream.on('error',function(err){
	// console.log(err.stack);
// });

// console.log('program ended');

//var zlib = require('zlib');

// // Compress the file input.txt to input.txt.gz
// fs.createReadStream('input.txt')
   // .pipe(zlib.createGzip())
   // .pipe(fs.createWriteStream('input.zip'));
  
// console.log("File Compressed.");

// // Decompress the file input.txt.gz to input.txt
// fs.createReadStream('input.zip')
   // .pipe(zlib.createGunzip())
   // .pipe(fs.createWriteStream('input.txt'));
  
// console.log("File Decompressed.");

//------Creating a Web Server using Node------
// create a server
http.createServer(function(req,res){
	
	var pathname = url.parse(req.url).pathname;
	console.log("Request for "+ pathname + " received");
	
	fs.readFile(pathname.substr(1), function(err, data){
		if(err){
			console.log(err);
			res.writeHead(404,{'Content-Type':'text/html'});
		}else{
			res.writeHead(200,{'Content-Type':'text/html'});
			res.write(data.toString());
			
			
		}
		res.end();
	});
	
	
}).listen(8081);
















