var arr = [[1,2],['arnab','devmalya']];
console.log(arr);
console.log(typeof(arr));