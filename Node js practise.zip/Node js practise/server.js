// only file upload throws error i don't know why

var express = require('express');
var app = express();
var fs = require('fs');

// var bodyParser = require('body-parser');
// var multer = require('multer');
// Create application/x-www-form-urlencoded parser
// var urlencodedParser = bodyParser.urlencoded({ extended: false });

// app.use(express.static('public'));
// app.use(urlencodedParser);
//app.use(multer({dest: '/uploads'}));
//app.use(multer({dest:'./uploads/'}).single('singleInputFileName'));
// app.get('/', function(req,res){
	// res.send('Hello World !');
// })

// app.get('/GETmethod.html', function(req, res){
	// res.sendFile( __dirname+'/'+"GETmethod.html");
// })

// app.post('/', function(req, res){
	// console.log("Got a POST request for the homepage");
	// res.send("Hello Post");
// })

// app.delete('/del_user', function(req, res){
	// console.log("Got a GET request for /list_user");
	// res.send("Hello DELETE");
// })

// app.get('/list_user', function(req,res){
	// console.log("Got a GET request for /list_user");
	// res.send("Page Listing");
// })

// app.get('/ab*cd', function(req, res){
	// console.log("Got a GET request for /ab*cd");
	// res.send("Page Pattern Match");
// })
//GETmethod html handler
// app.get('/process_get', function(req,res){
	// // prepare output in JSON format
	// response = {
		// first_name: req.query.first_name,
		// last_name: req.query.last_name
	// };
	// console.log(response);
	// res.end(JSON.stringify(response));
// })
//POSTmethod.html handler
// app.get('/POSTmethod.html', function (req, res) {
   // res.sendFile( __dirname + "/" + "POSTmethod.html" );
// })


// app.post('/process_post', urlencodedParser, function (req, res) {
   // // Prepare output in JSON format
   // response = {
      // first_name:req.body.first_name,
      // last_name:req.body.last_name
   // };
   // console.log(response);
   // res.end(JSON.stringify(response));
// })
//FileUpload.html handler

// app.get('/FileUpload.html', function(req,res){
	// res.sendFile(__dirname+"/"+'FileUpload.html');
// })

// app.post('/file_upload', function (req, res) {
   // console.log(req.files.file.name);
   // console.log(req.files.file.path);
   // console.log(req.files.file.type);
   // var file = __dirname + "/" + req.files.file.name;
   
   // fs.readFile( req.files.file.path, function (err, data) {
      // fs.writeFile(file, data, function (err) {
         // if( err ) {
            // console.log( err );
            // } else {
               // response = {
                  // message:'File uploaded successfully',
                  // filename:req.files.file.name
               // };
            // }
         
         // console.log( response );
         // res.end( JSON.stringify( response ) );
      // });
   // });
// })
// var cookieParser = require('cookie-parser')
// app.use(cookieParser())
// app.get('/', function(req, res) {
   // console.log("Cookies: ", req.cookies)
// })


//-----Node Js RESTful API------

// app.get('/listUsers', function(req, res){
	// fs.readFile(__dirname+"/"+"users.json", 'utf8', function(err, data){
		// console.log(data);
		// res.end(data);
	// });
// });

// app.get('/myHtml.html', function(req, res){
	// res.sendFile( __dirname+'/'+"myHtml.html");
// })
// var user = {
	// "user4":{
		// "name": "mohit",
		// "password": "password4",
		// "profession": "teacher",
		// "id": 4
	// },
	// "user5":{
		// "name": "rohan",
		// "password": "password5",
		// "profession": "professor",
		// "id": 5
	// }
// }



// app.post('/addUser', function(req, res){
	// fs.readFile(__dirname+'/'+"users.json", "utf8", function(err, data){
		// data = JSON.parse(data);
		// data["user4"] = user["user4"];
		// data["user5"] = user["user5"];
		// console.log(data);
		// res.end(JSON.stringify(data));
	// });
// })


// var server = app.listen(8081, function () {
   // var host = server.address().address
   // var port = server.address().port
   
   // console.log("Example app listening at http://%s:%s", host, port)
// })




