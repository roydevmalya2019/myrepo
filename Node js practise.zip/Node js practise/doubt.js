var fs = require('fs');

var myObject = {
	
	read: function(filename, callback){
		fs.readFile(filename, function(err, data){
		if(err) callback(err);	
		else
			callback(data);
		});
	}
	
}

myObject.read('myname.txt', function(val){
	console.log(val.toString());
});


